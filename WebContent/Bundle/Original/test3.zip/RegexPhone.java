$bar = <>;
if (($bar =~ /\d\d\d\d\d\d\d\d\d\d/)||($bar =~ /\d\d\d\s\d\d\d\s\d\d\d\d/)||($bar =~ /\d\d\d-\d\d\d-\d\d\d\d/)){
   print "True\n";
}else{
   print "False\n";
}

